<?php
namespace Drupal\employee\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\mydata\Controller
 */
class EmployeeListController extends ControllerBase {

     public function getContent() {
    // First we'll tell the user what's going on. This content can be found
    // in the twig template file: templates/description.html.twig.
    // @todo: Set up links to create nodes and point to devel module.
    $build = [
      'description' => [
        '#theme' => 'employeedata_description',
        '#description' => 'foo',
        '#attributes' => [],
      ],
    ];
    return $build;
  }

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function list() {
    /**return [
      '#type' => 'markup',
      '#markup' => $this->t('Implement method: display with parameter(s): $name'),
    ];*/
    //create table header
    $header_table = array(
        'id'=>    t('Sr No'),
        'name' => t('Name'),
        'email'=>t('Email'),
        'mobilenumber' => t('MobileNumber'),
        'dob' => t('DOB'),
        'gender' => t('Gender'),
        'age' => t('Age'),
       
        //'website' => t('Web site'),
        'opt' => t('operations'),
        'opt1' => t('operations'),
    );

   //select records from table
    $query = \Drupal::database()->select('employee_detail', 'm');
      $query->fields('m', ['id','emp_name','emp_mail','emp_number','emp_dob','emp_gender','emp_confirm_age']);
      $results = $query->execute()->fetchAll();
        $rows=array();
        
    $serial_no = 1 ;    
    foreach($results as $data){
        $delete = Url::fromUserInput('/employee/form/delete/'.$data->id);
        $edit   = Url::fromUserInput('/employee/form?num='.$data->id);

      //print the data from table
             $rows[] = array(
                's.no.'=>$serial_no,
				//'id' =>$data->id,
                'name' => $data->emp_name,
                'email' => $data->emp_mail,
                'mobilenumber' => $data->emp_number,
                'dob' => $data->emp_dob,
                'gender' => $data->emp_gender,
                'age' => $data->emp_confirm_age,
                //'website' => $data->website,

                 \Drupal::l('Delete', $delete),
                 \Drupal::l('Edit', $edit),
            );
            
            $serial_no ++ ; 
    }
    
    
    //display data in site
     $form['table'] = [
            '#type' => 'table',
            '#header' => $header_table,
            '#rows' => $rows,
            '#empty' => t('No users found'),
        ];
        
      
        
        global $base_url;
		$my_form  = '';
		$add_link = '<div class="add-link"><a href="'.$base_url.'/employee/form ">Add New123 </a></div>';
		
		$my_form .= $add_link;
		$my_form .=  $form;
		
		 return $form;
}

}
