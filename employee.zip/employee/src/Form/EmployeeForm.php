<?php
/**
 * @file
 * Contains \Drupal\employee\Form\EmployeeForm.
 */
 
/**
* Defined route of the core files and path for the current file Start
*/ 
namespace Drupal\employee\Form;
use Drupal\user\Entity\User;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
* Defined route of the core files and path for the current file End
*/ 


/**
* basic controller Strat
*/
class EmployeeForm extends FormBase {
	
	
/**
* Set Employee Form Id Start
*/
  public function getFormId() {
    return 'employee_detail_form';
  }
/**
* Set Employee Form Id End
*/



/**
* Build The Form
*/
public function buildForm(array $form, FormStateInterface $form_state) {
	
	//smae drupal7 and drupal8
	$record = array();
	if (isset($_GET['num'])) {
	 $query = db_select('employee_detail','m')
		    ->condition('id', $_GET['num'])
            ->fields('m');
        $record = $query->execute()->fetchAssoc();
        //echo   $edit_nid = $record['emp_gender'];
        //echo   $edit_nid = $record['emp_confirm_age'];
	}
	
    
    $form['employee_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Employee Name:'),
      '#required' => TRUE,
      '#default_value' => (isset($record['emp_name']) && $_GET['num']) ? $record['emp_name']:'',
    );
    $form['employee_mail'] = array(
      '#type' => 'email',
      '#title' => t('Email ID:'),
     // '#required' => TRUE,
     '#default_value' => (isset($record['emp_mail']) && $_GET['num']) ? $record['emp_mail']:'',
     
    );
    $form['employee_number'] = array (
      '#type' => 'tel',
      '#title' => t('Mobile no'),
      '#default_value' => (isset($record['emp_number']) && $_GET['num']) ? $record['emp_number']:'',
    );
    $form['employee_dob'] = array (
      '#type' => 'date',
      '#title' => t('DOB'),
     // '#required' => TRUE,
     '#default_value' => (isset($record['emp_dob']) && $_GET['num']) ? $record['emp_dob']:'',
    );
 
    $genders = array('male' => t('Male'), 'female' => t('Female'), ); 
    $form['employee_gender'] = array (
      '#type' => 'select',
      '#title' => ('Gender'),
      '#options' => $genders,
      '#default_value' => (isset($record['emp_gender']) && $_GET['num']) ? $record['emp_gender']:'',
      
    );
    
    $age = array('yes' => t('Yes'), 'no' => t('No'), ); 
    $form['employee_confirmation'] = array (
      '#type' => 'radios',
      '#title' => ('Are you above 18 years old?'),
      '#options' => $age,
      '#default_value' => (isset($record['emp_confirm_age']) && $_GET['num']) ? $record['emp_confirm_age']:'',

    );
    //~ $form['candidate_copy'] = array(
      //~ '#type' => 'checkbox',
      //~ '#title' => t('Send me a copy of the application.'),
    //~ );
    
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    );
    return $form;
  }
/**
* Build The Form End
*/  
  
  

/**
* Employee Form Validation Start
*/  
  
  public function validateForm(array &$form, FormStateInterface $form_state) {
	}
/**
* Employee Form Validation End
*/ 

 
 
  
/**
* submit The Form Start
*/

		public function submitForm(array &$form, FormStateInterface $form_state) {
			//print '<pre>'; print_r ($form_state);exit;
		    // drupal_set_message($this->t('@can_name ,Your application is being submitted!', array('@can_name' => $form_state->getValue('candidate_name'))));
			
			//~ foreach ($form_state->getValues() as $key => $value) {
			  //~ drupal_set_message($key . ': ' . $value);
			//~ }
			
			
			
			$form_state_values = $form_state->getValues();
			
			 $name = $form_state_values['employee_name'];
			 $mail = $form_state_values['employee_mail'];
			 $number = $form_state_values['employee_number'];
			 $dob = $form_state_values['employee_dob'];
			 $gender = $form_state_values['employee_gender'];
			 $e_confirmation = $form_state_values['employee_confirmation'];
			 
			  if (isset($_GET['num'])) {
			  $field  = array(
				        'emp_name' => $name,
						'emp_mail' => $mail,
						'emp_number' => $number,
						'emp_dob' => $dob,
						'emp_gender' => $gender,
						'emp_confirm_age' => $e_confirmation,
			  );
			  $query = \Drupal::database();
			  $query->update('employee_detail')
				  ->fields($field)
				  ->condition('id', $_GET['num'])
				  ->execute();
			  drupal_set_message("Entry succesfully updated");
			  $form_state->setRedirect('employee.emp_list');
			  
			  }
			  else
			  {
				  
			  $data = array(
						'emp_name' => $name,
						'emp_mail' => $mail,
						'emp_number' => $number,
						'emp_dob' => $dob,
						'emp_gender' => $gender,
						'emp_confirm_age' => $e_confirmation,
						);
						
			 $query = db_insert('employee_detail')
			          ->fields($data);
			 $submit_query = $query->execute();
			 if($submit_query) {
				drupal_set_message('Employee successfully Submitted The Entry', $type = 'status');
				//drupal_set_message("succesfully updated");
                $form_state->setRedirect('employee.emp_list');		
  
			 }	
			 else{	
				drupal_set_message(t('Error while inserting data into database.'), 'error');
			 }
         
	       } /* else end */
	       
		 } /* submitForm end */
 
/**
* submit The Form End above
*/

		
}
/**
* basic controller End above
*/


















